package com.bookstore.service;

import java.util.List;

import com.bookstore.dto.BookRequestDto;
import com.bookstore.dto.BookResponseDto;
import com.bookstore.dto.BookResponseProj;
import com.bookstore.entity.Book;

public interface BookService {

	void addBook(BookRequestDto bookRequestDto);

	List<BookResponseDto> getAllBooks();

	BookResponseDto getBookById(Integer bookId);

	List<BookResponseProj> getBookByName(String bookName);

	List<BookResponseProj> findByGenre(String genre);

	void updateBook(BookRequestDto bookRequestDto, Integer bookId);

}
